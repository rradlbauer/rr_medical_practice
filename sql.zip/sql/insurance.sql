INSERT INTO `insurance` (`id`, `fullName`) VALUES
                                               ('AUVA', 'Allgemeine Unfallversicherungsanstalt'),
                                               ('SVS','Sozialversicherungsanstalt der Selbständigen'),
                                               ('BVAEV','Versicherungsanstalt öffentlich Bediensteter, Eisenbahnen und Bergbau'),
                                               ('ÖGK','Österreichische Gesundheitskasse'),
                                               ('PVA','Pensionsversicherungsanstalt (der Angestellten und Arbeiter) ');
