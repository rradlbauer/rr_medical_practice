


CREATE TABLE `adress` (
                          `id` int(11) NOT NULL,
                          `city` varchar(255) DEFAULT NULL,
                          `street` varchar(255) DEFAULT NULL,
                          `zip` int(11) NOT NULL,
                          `patient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `agent` (
                         `id` int(11) NOT NULL,
                         `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `anamnesis` (
                             `id` int(11) NOT NULL,
                             `text` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `diagnosis` (
                             `id` int(11) NOT NULL,
                             `comment` varchar(255) DEFAULT NULL,
                             `diagnosisDate` date DEFAULT NULL,
                             `diagnosis_code` varchar(255) DEFAULT NULL,
                             `patient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `diagnosiscode` (
                                 `icd10` varchar(255) NOT NULL,
                                 `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `insurance` (
                             `id` varchar(255) NOT NULL,
                             `fullName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `medication` (
                              `id` int(11) NOT NULL,
                              `agent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `patient` (
                           `id` int(11) NOT NULL,
                           `birth` date DEFAULT NULL,
                           `gender` char(1) NOT NULL,
                           `name` varchar(255) DEFAULT NULL,
                           `phone` varchar(255) DEFAULT NULL,
                           `svnr` bigint(20) NOT NULL,
                           `insurance_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `physicaltherapy` (
                                   `description` varchar(255) DEFAULT NULL,
                                   `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `schedule` (
                            `id` int(11) NOT NULL,
                            `begin` datetime DEFAULT NULL,
                            `cause` int(11) DEFAULT NULL,
                            `end` datetime DEFAULT NULL,
                            `ssn` bigint(20) DEFAULT NULL,
                            `patient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `symptom` (
                           `id` int(11) NOT NULL,
                           `onset` date DEFAULT NULL,
                           `symptom_id` int(11) DEFAULT NULL,
                           `anamnesis_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `symptomcode` (
                               `id` int(11) NOT NULL,
                               `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `treatment` (
                             `id` int(11) NOT NULL,
                             `beginOfTreatment` date DEFAULT NULL,
                             `endOfTreatment` date DEFAULT NULL,
                             `diagnosis_id` int(11) DEFAULT NULL,
                             `patient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `visit` (
                         `id` int(11) NOT NULL,
                         `date` datetime DEFAULT NULL,
                         `anamnesis_id` int(11) DEFAULT NULL,
                         `patient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `adress`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FK3cao1fc43lo8uj606oifc7tsw` (`patient_id`);

ALTER TABLE `agent`
    ADD PRIMARY KEY (`id`);

ALTER TABLE `anamnesis`
    ADD PRIMARY KEY (`id`);

ALTER TABLE `diagnosis`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FKo4yfyx3dse3535ly5rh9efebx` (`diagnosis_code`),
  ADD KEY `FK7gcdpb8csnfsi9voax5q9gixg` (`patient_id`);

ALTER TABLE `diagnosiscode`
    ADD PRIMARY KEY (`icd10`);

ALTER TABLE `insurance`
    ADD PRIMARY KEY (`id`);

ALTER TABLE `medication`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FKtrd5maia0hyh8umr5psq06gyp` (`agent_id`);

ALTER TABLE `patient`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FK42mjd38kr1sowctjn4wk8n3ol` (`insurance_name`);

ALTER TABLE `physicaltherapy`
    ADD PRIMARY KEY (`id`);

ALTER TABLE `schedule`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FK22aib6e0ixto1jhty9hvi76j3` (`patient_id`);

ALTER TABLE `symptom`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FKfpbeai8ream94xme6cgh01b8t` (`symptom_id`),
  ADD KEY `FKgmf96o2qqg897py8kgrdcabn8` (`anamnesis_id`);

ALTER TABLE `symptomcode`
    ADD PRIMARY KEY (`id`);

ALTER TABLE `treatment`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FKddt4u42jk0oxlpcd5ry6f0gst` (`diagnosis_id`),
  ADD KEY `FKksawx3hel8rl2rttwpx9o6thf` (`patient_id`);

ALTER TABLE `visit`
    ADD PRIMARY KEY (`id`),
  ADD KEY `FK5absf4djxidfq2ajmklsaf7ai` (`anamnesis_id`),
  ADD KEY `FKkiuh4qcfnf1j5dfgdxkc9o6sh` (`patient_id`);


ALTER TABLE `adress`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `agent`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `anamnesis`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `diagnosis`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `patient`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `schedule`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `symptom`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `symptomcode`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `treatment`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `visit`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


ALTER TABLE `adress`
    ADD CONSTRAINT `FK3cao1fc43lo8uj606oifc7tsw` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`);

ALTER TABLE `diagnosis`
    ADD CONSTRAINT `FK7gcdpb8csnfsi9voax5q9gixg` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  ADD CONSTRAINT `FKo4yfyx3dse3535ly5rh9efebx` FOREIGN KEY (`diagnosis_code`) REFERENCES `diagnosiscode` (`icd10`);

ALTER TABLE `medication`
    ADD CONSTRAINT `FKcncmplh2pg3d05yu5royl0ryn` FOREIGN KEY (`id`) REFERENCES `treatment` (`id`),
  ADD CONSTRAINT `FKtrd5maia0hyh8umr5psq06gyp` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`);

ALTER TABLE `patient`
    ADD CONSTRAINT `FK42mjd38kr1sowctjn4wk8n3ol` FOREIGN KEY (`insurance_name`) REFERENCES `insurance` (`id`);

ALTER TABLE `physicaltherapy`
    ADD CONSTRAINT `FK82rei6bda85ln9imogfcblyue` FOREIGN KEY (`id`) REFERENCES `treatment` (`id`);

ALTER TABLE `schedule`
    ADD CONSTRAINT `FK22aib6e0ixto1jhty9hvi76j3` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`);

ALTER TABLE `symptom`
    ADD CONSTRAINT `FKfpbeai8ream94xme6cgh01b8t` FOREIGN KEY (`symptom_id`) REFERENCES `symptomcode` (`id`),
  ADD CONSTRAINT `FKgmf96o2qqg897py8kgrdcabn8` FOREIGN KEY (`anamnesis_id`) REFERENCES `anamnesis` (`id`);

ALTER TABLE `treatment`
    ADD CONSTRAINT `FKddt4u42jk0oxlpcd5ry6f0gst` FOREIGN KEY (`diagnosis_id`) REFERENCES `diagnosis` (`id`),
  ADD CONSTRAINT `FKksawx3hel8rl2rttwpx9o6thf` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`);

ALTER TABLE `visit`
    ADD CONSTRAINT `FK5absf4djxidfq2ajmklsaf7ai` FOREIGN KEY (`anamnesis_id`) REFERENCES `anamnesis` (`id`),
  ADD CONSTRAINT `FKkiuh4qcfnf1j5dfgdxkc9o6sh` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`);


